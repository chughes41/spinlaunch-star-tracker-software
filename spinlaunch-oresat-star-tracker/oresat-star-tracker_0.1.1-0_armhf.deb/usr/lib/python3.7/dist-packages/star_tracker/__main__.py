"""Main for the OreSat Star Tracker daemon module."""

from star_tracker.main import main

if __name__ == "__main__":
    main()
